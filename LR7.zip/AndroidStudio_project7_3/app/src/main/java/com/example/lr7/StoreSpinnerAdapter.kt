/*
package com.example.lr7

import android.content.Context
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.TextView
import com.example.lr7.data.Store

class StoreSpinnerAdapter(
    context: Context,
    stores: List<Store>
) : ArrayAdapter<Store>(context, android.R.layout.simple_spinner_item, stores) {

    init {
        // Встановлюємо layout для відображення випадаючого списку
        setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
    }

    // Відображення текстового представлення магазину у Spinner
    override fun getItem(position: Int): Store? {
        return super.getItem(position)
    }

    override fun getDropDownView(position: Int, convertView: View?, parent: ViewGroup): View {
        val view = super.getDropDownView(position, convertView, parent) as TextView
        // Встановлення тексту із поля categоry для магазину
        view.text = getItem(position)?.categоry
        return view
    }
}
*/





package com.example.lr7

import android.content.Context
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.TextView
import com.example.lr7.data.Store

class StoreSpinnerAdapter(
    context: Context,
    stores: List<Store>
) : ArrayAdapter<Store>(context, android.R.layout.simple_spinner_item, stores) {

    init {
        // Встановлюємо layout для відображення випадаючого списку
        setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
    }

    // Відображення текстового представлення магазину у Spinner
    override fun getItem(position: Int): Store? {
        return super.getItem(position)
    }

    override fun getDropDownView(position: Int, convertView: View?, parent: ViewGroup): View {
        val view = super.getDropDownView(position, convertView, parent) as TextView
        // Встановлення тексту із поля categоry для магазину
        view.text = getItem(position)?.storeCategory
        return view
    }
}
