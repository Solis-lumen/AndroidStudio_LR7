package com.example.lr7.data

data class ProductNamePrice(
    val productName: String,
    val productPrice: Double?,
)
