/*
package com.example.lr7.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface MainDbDao {
    // Product
    @Insert
    fun insertProduct(product: Product)
    @Query(value = "SELECT * FROM products")
    fun getAllProducts() : Flow<List<Product>>
    @Update
    fun updateProduct(product: Product)
    @Delete
    fun deleteProduct(product: Product)

    @Query(value = "SELECT products.product_id, products.product_name, products.product_price, products.store_category " +
            "FROM products JOIN stores ON products.store_category = stores.store_category " +
            "WHERE stores.store_category = :storeCategory ORDER BY products.product_id ASC")
    fun getProductsByCategory(storeCategory : String) : List<Product>

    // Store
    @Insert
    fun insertStore(store: Store)
    @Query(value = "SELECT * FROM stores")
    fun getAllStores() : Flow<List<Store>>
    @Delete
    fun deleteStore(store: Store)
    @Update
    fun updateStore(store: Store)

    //Product&Store
    @Query(value = "SELECT product_id, products.product_name as product_name, products.product_price as product_price, stores.store_id, stores.store_name as store_name, stores.store_category as store_category FROM products JOIN stores ON products.store_category = stores.store_category")
    fun getAllProductsWithStores() : List<ProductWithStore>

}
*/




package com.example.lr7.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface MainDbDao {
    // Product operations
    @Insert
    fun insertProduct(product: Product)

    @Query("SELECT * FROM products")
    fun getAllProducts(): Flow<List<Product>>

    @Update
    fun updateProduct(product: Product)

    @Delete
    fun deleteProduct(product: Product)

    @Query("""
        SELECT products.product_id, products.product_name, products.product_price, products.store_category 
        FROM products JOIN stores ON products.store_category = stores.store_category 
        WHERE stores.store_category = :storeCategory ORDER BY products.product_id ASC
    """)
    fun getProductsByCategory(storeCategory: String): List<Product>


    // Store operations
    @Insert
    fun insertStore(store: Store)

    @Query("SELECT * FROM stores")
    fun getAllStores(): Flow<List<Store>>

    @Update
    fun updateStore(store: Store)

    @Delete
    fun deleteStore(store: Store)


    // Product and Store relationship
    @Transaction
    @Query("""
        SELECT stores.store_id, stores.store_name, stores.store_category, 
        products.product_id, products.product_name, products.product_price
        FROM stores
        LEFT JOIN products ON stores.store_category = products.store_category
    """)
    fun getAllProductsWithStores(): List<ProductWithStore>

    // Отримання частини даних із таблиці products
    @Query("SELECT product_name AS productName, product_price AS productPrice FROM products")
    fun getProductNamesAndPrices(): List<ProductNamePrice>
}
