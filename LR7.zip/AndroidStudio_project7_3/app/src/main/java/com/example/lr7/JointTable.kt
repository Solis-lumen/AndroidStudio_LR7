/*
package com.example.lr7

import android.os.Bundle
import android.view.View
import android.widget.TableRow
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import com.example.lr7.data.MainDb
import com.example.lr7.data.MainDbDao
import com.example.lr7.databinding.ActivityJointTableBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class JointTable : AppCompatActivity() {
    lateinit var binding: ActivityJointTableBinding
    lateinit var db: MainDb
    lateinit var dao: MainDbDao

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityJointTableBinding.inflate(layoutInflater)
        enableEdgeToEdge()
        setContentView(binding.root)
        db = MainDb.getDb(this)
        dao = db.getDao()
    }

    fun buttonBackClick(view: View) {
        finish()
    }

    // Метод для виведення продуктів по категорії
    fun buttonGetProductsByStoreClick(view: View) {
        GlobalScope.launch {
            val productsByStore = withContext(Dispatchers.IO) {
                dao.getProductsByCategory(binding.editTextCategoryOfStoreToFind.text.toString())
            }

            withContext(Dispatchers.Main) {
                binding.tableLayoutProducts.removeAllViews() // Очищення таблиці

                // Додавання назв стовпців таблиці
                val headerRow = TableRow(this@JointTable)
                val headers = listOf("Product ID", "Product name", "Product price")
                headers.forEach { text ->
                    val textView = TextView(this@JointTable)
                    textView.text = text
                    textView.setPadding(8, 8, 8, 8)
                    textView.setBackgroundResource(R.drawable.table_cell_border)
                    headerRow.addView(textView)
                }
                binding.tableLayoutProducts.addView(headerRow)

                // Додавання даних продуктів у таблицю
                productsByStore.forEach { item ->
                    val row = TableRow(this@JointTable)
                    val productData = listOf(item.id.toString(), item.name, item.price.toString())

                    productData.forEach { data ->
                        val textView = TextView(this@JointTable)
                        textView.text = data
                        textView.setPadding(8, 8, 8, 8)
                        textView.setBackgroundResource(R.drawable.table_cell_border)
                        row.addView(textView)
                    }
                    binding.tableLayoutProducts.addView(row)
                }
            }
        }
    }

    // Метод для виведення усіх продуктів з магазинами
    fun buttonGetProductsWithStoresClick(view: View) {
        GlobalScope.launch {
            val productsWithStores = withContext(Dispatchers.IO) {
                dao.getAllProductsWithStores()
            }

            withContext(Dispatchers.Main) {
                binding.tableLayoutProducts.removeAllViews() // Очищення таблиці

                // Додавання назв стовпців таблиці
                val headerRow = TableRow(this@JointTable)
                val headers = listOf("Store ID", "Store name", "Store category", "Product ID", "Product name", "Product price")
                headers.forEach { text ->
                    val textView = TextView(this@JointTable)
                    textView.text = text
                    textView.setPadding(8, 8, 8, 8)
                    textView.setBackgroundResource(R.drawable.table_cell_border)
                    headerRow.addView(textView)
                }
                binding.tableLayoutProducts.addView(headerRow)

                // Додавання даних продуктів у таблицю
                productsWithStores.forEach { item ->
                    val row = TableRow(this@JointTable)
                    val productData = listOf(item.store_id.toString(), item.store_name, item.store_category, item.product_id.toString(), item.product_name, item.product_price.toString())

                    productData.forEach { data ->
                        val textView = TextView(this@JointTable)
                        textView.text = data
                        textView.setPadding(8, 8, 8, 8)
                        textView.setBackgroundResource(R.drawable.table_cell_border)
                        row.addView(textView)
                    }
                    binding.tableLayoutProducts.addView(row)
                }
            }
        }
    }
}
*/






package com.example.lr7

import android.os.Bundle
import android.view.View
import android.widget.TableRow
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.lr7.data.MainDb
import com.example.lr7.data.MainDbDao
import com.example.lr7.data.ProductNamePrice
import com.example.lr7.databinding.ActivityJointTableBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class JointTable : AppCompatActivity() {
    private lateinit var binding: ActivityJointTableBinding
    private lateinit var db: MainDb
    private lateinit var dao: MainDbDao

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityJointTableBinding.inflate(layoutInflater)
        setContentView(binding.root)

        db = MainDb.getDb(this)
        dao = db.getDao()
    }

    fun buttonBackClick(view: View) {
        finish()
    }

    // Method to display products by category
    fun buttonGetProductsByStoreClick(view: View) {
        GlobalScope.launch {
            val productsByStore = withContext(Dispatchers.IO) {
                dao.getProductsByCategory(binding.editTextCategoryOfStoreToFind.text.toString())
            }

            withContext(Dispatchers.Main) {
                binding.tableLayoutProducts.removeAllViews()

                // Adding table headers
                val headerRow = TableRow(this@JointTable)
                val headers = listOf("Product ID", "Product name", "Product price")
                headers.forEach { text ->
                    val textView = TextView(this@JointTable)
                    textView.text = text
                    textView.setPadding(8, 8, 8, 8)
                    textView.setBackgroundResource(R.drawable.table_cell_border)
                    headerRow.addView(textView)
                }
                binding.tableLayoutProducts.addView(headerRow)

                // Adding product data rows
                productsByStore.forEach { item ->
                    val row = TableRow(this@JointTable)
                    val productData = listOf(item.productId.toString(), item.productName, item.productPrice.toString())

                    productData.forEach { data ->
                        val textView = TextView(this@JointTable)
                        textView.text = data
                        textView.setPadding(8, 8, 8, 8)
                        textView.setBackgroundResource(R.drawable.table_cell_border)
                        row.addView(textView)
                    }
                    binding.tableLayoutProducts.addView(row)
                }
            }
        }
    }

    // Method to display all products with their associated stores
    fun buttonGetProductsWithStoresClick(view: View) {
        GlobalScope.launch {
            val productsWithStores = withContext(Dispatchers.IO) {
                dao.getAllProductsWithStores()
            }

            withContext(Dispatchers.Main) {
                binding.tableLayoutProducts.removeAllViews() // Clear the table

                // Adding table headers
                val headerRow = TableRow(this@JointTable)
                val headers = listOf("Store ID", "Store name", "Store category", "Product ID", "Product name", "Product price")
                headers.forEach { text ->
                    val textView = TextView(this@JointTable)
                    textView.text = text
                    textView.setPadding(8, 8, 8, 8)
                    textView.setBackgroundResource(R.drawable.table_cell_border)
                    headerRow.addView(textView)
                }
                binding.tableLayoutProducts.addView(headerRow)

                // Adding product and store data rows
                productsWithStores.forEach { item ->
                    item.products.forEach { product -> // Loop through each product associated with the store
                        val row = TableRow(this@JointTable)
                        val productData = listOf(
                            item.store.storeId.toString(),
                            item.store.storeName,
                            item.store.storeCategory,
                            product.productId.toString(),
                            product.productName,
                            product.productPrice.toString()
                        )

                        productData.forEach { data ->
                            val textView = TextView(this@JointTable)
                            textView.text = data
                            textView.setPadding(8, 8, 8, 8)
                            textView.setBackgroundResource(R.drawable.table_cell_border)
                            row.addView(textView)
                        }
                        binding.tableLayoutProducts.addView(row)
                    }
                }
            }
        }
    }

    // Method to display only product names and prices
    fun buttonGetProductNamesAndPricesClick(view: View) {
        GlobalScope.launch {
            val productNamesAndPrices = withContext(Dispatchers.IO) {
                dao.getProductNamesAndPrices()
            }

            withContext(Dispatchers.Main) {
                binding.tableLayoutProducts.removeAllViews()

                // Adding table headers
                val headerRow = TableRow(this@JointTable)
                val headers = listOf("Product name", "Product price")
                headers.forEach { text ->
                    val textView = TextView(this@JointTable)
                    textView.text = text
                    textView.setPadding(8, 8, 8, 8)
                    textView.setBackgroundResource(R.drawable.table_cell_border)
                    headerRow.addView(textView)
                }
                binding.tableLayoutProducts.addView(headerRow)

                // Adding product name and price rows
                productNamesAndPrices.forEach { item: ProductNamePrice ->
                    val row = TableRow(this@JointTable)
                    val productData = listOf(item.productName, item.productPrice.toString())

                    productData.forEach { data ->
                        val textView = TextView(this@JointTable)
                        textView.text = data
                        textView.setPadding(8, 8, 8, 8)
                        textView.setBackgroundResource(R.drawable.table_cell_border)
                        row.addView(textView)
                    }
                    binding.tableLayoutProducts.addView(row)
                }
            }
        }
    }

}
