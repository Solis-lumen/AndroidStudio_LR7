/*
package com.example.lr7

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TableRow
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.addTextChangedListener
import androidx.lifecycle.asLiveData
import com.example.lr7.data.Store
import com.example.lr7.data.Product
import com.example.lr7.data.MainDb
import com.example.lr7.data.MainDbDao
import com.example.lr7.databinding.ActivityMainBinding
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity()
{
    lateinit var binding: ActivityMainBinding
    lateinit var db: MainDb
    lateinit var dao: MainDbDao

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        enableEdgeToEdge()
        setContentView(binding.root)
        db = MainDb.getDb(this)
        dao = db.getDao()

        // Оновлення даних в таблиці з магазинами
        dao.getAllStores().asLiveData().observe(this) { stores ->

            // Спінер
            val storeAdapter = StoreSpinnerAdapter(this, stores)
            binding.spinnerStores.adapter = storeAdapter
            binding.spinnerStores.setSelection(0)

            val storesTable = binding.storesTable
            storesTable.removeAllViews()

            // Заголовки
            val headersRow = TableRow(this)
            val textViewId = TextView(this)
            textViewId.text = "id"
            val textViewStoreName = TextView(this)
            textViewStoreName.text = "store_name"
            val textViewStoreCategory = TextView(this)
            textViewStoreCategory.text = "store_category"
            headersRow.addView(textViewId)
            headersRow.addView(textViewStoreName)
            headersRow.addView(textViewStoreCategory)
            storesTable.addView(headersRow)

            // Виведення усіх магазинів
            stores.forEach { store ->
                val row = TableRow(this)
                val lp = TableRow.LayoutParams(TableRow.LayoutParams.WRAP_CONTENT)
                row.layoutParams = lp

                val textViewId = TextView(this)
                textViewId.text = store.id.toString()
                val editStoreName = EditText(this)
                editStoreName.setText(store.name)
                val editStoreCategory = EditText(this)
                editStoreCategory.setText(store.categоry)

                val buttonDelete = Button(this)
                buttonDelete.setText("Delete")
                val buttonUpdate = Button(this)
                buttonUpdate.setText("Update")
                buttonUpdate.isEnabled = false

                editStoreName.addTextChangedListener {
                    buttonUpdate.isEnabled = true
                }
                editStoreCategory.addTextChangedListener {
                    buttonUpdate.isEnabled = true
                }

                // Обробка оновлення
                buttonUpdate.setOnClickListener {
                    CoroutineScope(Dispatchers.IO).launch {
                        try {
                            store.name = editStoreName.text.toString()
                            dao.updateStore(store)
                            store.categоry = editStoreCategory.text.toString()
                            dao.updateStore(store)

                            withContext(Dispatchers.Main) {
                                Toast.makeText(applicationContext, "Store updated", Toast.LENGTH_SHORT).show()
                            }
                        } catch (e: Exception) {
                            withContext(Dispatchers.Main) {
                                Toast.makeText(applicationContext, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                }

                // Обробка видалення
                buttonDelete.setOnClickListener {
                    CoroutineScope(Dispatchers.IO).launch {
                        try {
                            dao.deleteStore(store)

                            withContext(Dispatchers.Main) {
                                Toast.makeText(applicationContext, "Store deleted", Toast.LENGTH_SHORT).show()
                            }
                        } catch (e: Exception) {
                            withContext(Dispatchers.Main) {
                                Toast.makeText(applicationContext, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                }

                row.addView(textViewId)
                row.addView(editStoreName)
                row.addView(editStoreCategory)
                row.addView(buttonUpdate)
                row.addView(buttonDelete)
                storesTable.addView(row)
            }
        }

        // Виведення усіх продуктів
        dao.getAllProducts().asLiveData().observe(this) { products ->
            val productsTable = binding.productsTable
            productsTable.removeAllViews()

            // Заголовки
            val headersRow = TableRow(this)
            val textViewId = TextView(this)
            val textViewProductName = TextView(this)
            val textViewStoreCategory = TextView(this)
            val textViewProductPrice = TextView(this)

            textViewId.text = "id"
            textViewProductName.text = "product_name"
            textViewStoreCategory.text = "store_category"
            textViewProductPrice.text = "product_price"

            headersRow.addView(textViewId)
            headersRow.addView(textViewProductName)
            headersRow.addView(textViewStoreCategory)
            headersRow.addView(textViewProductPrice)
            productsTable.addView(headersRow)

            products.forEach { product ->
                val row = TableRow(this)

                val textViewProductId = TextView(this)
                val editTextProductNameValue = EditText(this)
                val editTextStoreCategoryValue = EditText(this)
                val editTextProductPriceValue = EditText(this)
                val updateButton = Button(this)
                updateButton.text = "Update"
                updateButton.isEnabled = false
                val deleteButton = Button(this)
                deleteButton.text = "Delete"

                textViewProductId.text = product.id.toString()
                editTextProductNameValue.setText(product.name)
                editTextStoreCategoryValue.setText(product.store_category)
                editTextProductPriceValue.setText(product.price.toString())

                row.addView(textViewProductId)
                row.addView(editTextProductNameValue)
                row.addView(editTextStoreCategoryValue)
                row.addView(editTextProductPriceValue)
                row.addView(updateButton)
                row.addView(deleteButton)

                // Розблокування кнопки Update
                editTextProductNameValue.addTextChangedListener {
                    updateButton.isEnabled = true
                }
                editTextStoreCategoryValue.addTextChangedListener {
                    updateButton.isEnabled = true
                }
                editTextProductPriceValue.addTextChangedListener {
                    updateButton.isEnabled = true
                }

                // Обробка оновлення
                updateButton.setOnClickListener {
                    CoroutineScope(Dispatchers.IO).launch {
                        try {
                            product.name = editTextProductNameValue.text.toString()
                            product.store_category = editTextStoreCategoryValue.text.toString()
                            product.price = editTextProductPriceValue.text.toString().toDoubleOrNull()
                            dao.updateProduct(product)
                            withContext(Dispatchers.Main) {
                                Toast.makeText(applicationContext, "Product updated", Toast.LENGTH_SHORT).show()
                            }
                        } catch (e: Exception) {
                            withContext(Dispatchers.Main) {
                                Toast.makeText(applicationContext, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                }

                // Обробка видалення
                deleteButton.setOnClickListener {
                    CoroutineScope(Dispatchers.IO).launch {
                        try {
                            dao.deleteProduct(product)

                            withContext(Dispatchers.Main) {
                                Toast.makeText(applicationContext, "Product deleted", Toast.LENGTH_SHORT).show()
                            }
                        } catch (e: Exception) {
                            withContext(Dispatchers.Main) {
                                Toast.makeText(applicationContext, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                }

                productsTable.addView(row)
            }
        }
    }

    fun buttonAddStoreClick(view: View) {
        if (binding.editTextStoreName.text.toString() == "" || binding.editTextStoreCategory.text.toString() == "")
            return

        CoroutineScope(Dispatchers.IO).launch {
            try {
                val store = Store(null, binding.editTextStoreName.text.toString(), binding.editTextStoreCategory.text.toString())
                dao.insertStore(store)
                withContext(Dispatchers.Main) {
                    binding.editTextStoreName.text.clear()
                    binding.editTextStoreCategory.text.clear()
                }
            } catch (ex: Exception) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(applicationContext, "Error: ${ex.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    fun addProductClick(view: View)
    {
        val productName = binding.editTextNewProductName.text.toString()
        val productPrice = binding.editTextNewProductPrice.text.toString().toDoubleOrNull()
        val storeCategory = (binding.spinnerStores.selectedItem as Store).categоry

        if (productName == "" || productPrice == 0.0)
            return

        CoroutineScope(Dispatchers.IO).launch {
            try {
                val product = Product(null, productName, storeCategory, productPrice)
                dao.insertProduct(product)
                withContext(Dispatchers.Main) {
                    binding.editTextNewProductName.text.clear()
                    binding.editTextNewProductPrice.text.clear()
                }
            } catch (ex: Exception) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(applicationContext, "Error: ${ex.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    fun openFullTableClick(view: View)
    {
        val intent = Intent(this, JointTable::class.java)
        startActivity(intent)
    }
}
*/





package com.example.lr7

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TableRow
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.addTextChangedListener
import androidx.lifecycle.asLiveData
import com.example.lr7.data.Store
import com.example.lr7.data.Product
import com.example.lr7.data.MainDb
import com.example.lr7.data.MainDbDao
import com.example.lr7.databinding.ActivityMainBinding
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity()
{
    lateinit var binding: ActivityMainBinding
    lateinit var db: MainDb
    lateinit var dao: MainDbDao

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        enableEdgeToEdge()
        setContentView(binding.root)
        db = MainDb.getDb(this)
        dao = db.getDao()

        // Оновлення даних в таблиці з магазинами
        dao.getAllStores().asLiveData().observe(this) { stores ->
            // Спінер
            val storeAdapter = StoreSpinnerAdapter(this, stores)
            binding.spinnerStores.adapter = storeAdapter
            binding.spinnerStores.setSelection(0)

            val storesTable = binding.storesTable
            storesTable.removeAllViews()

            // Заголовки
            val headersRow = TableRow(this)
            val textViewId = TextView(this)
            textViewId.text = "id"
            val textViewStoreName = TextView(this)
            textViewStoreName.text = "store_name"
            val textViewStoreCategory = TextView(this)
            textViewStoreCategory.text = "store_category"
            headersRow.addView(textViewId)
            headersRow.addView(textViewStoreName)
            headersRow.addView(textViewStoreCategory)
            storesTable.addView(headersRow)

            // Виведення усіх магазинів
            stores.forEach { store ->
                val row = TableRow(this)
                val lp = TableRow.LayoutParams(TableRow.LayoutParams.WRAP_CONTENT)
                row.layoutParams = lp

                val textViewId = TextView(this)
                textViewId.text = store.storeId.toString()
                val editStoreName = EditText(this)
                editStoreName.setText(store.storeName)
                val editStoreCategory = EditText(this)
                editStoreCategory.setText(store.storeCategory)

                val buttonDelete = Button(this)
                buttonDelete.setText("Delete")
                val buttonUpdate = Button(this)
                buttonUpdate.setText("Update")
                buttonUpdate.isEnabled = false

                editStoreName.addTextChangedListener {
                    buttonUpdate.isEnabled = true
                }
                editStoreCategory.addTextChangedListener {
                    buttonUpdate.isEnabled = true
                }

                // Обробка оновлення
                buttonUpdate.setOnClickListener {
                    CoroutineScope(Dispatchers.IO).launch {
                        try {
                            store.storeName = editStoreName.text.toString()
                            dao.updateStore(store)
                            store.storeCategory = editStoreCategory.text.toString()
                            dao.updateStore(store)

                            withContext(Dispatchers.Main) {
                                Toast.makeText(applicationContext, "Store updated", Toast.LENGTH_SHORT).show()
                            }
                        } catch (e: Exception) {
                            withContext(Dispatchers.Main) {
                                Toast.makeText(applicationContext, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                }

                // Обробка видалення
                buttonDelete.setOnClickListener {
                    CoroutineScope(Dispatchers.IO).launch {
                        try {
                            dao.deleteStore(store)

                            withContext(Dispatchers.Main) {
                                Toast.makeText(applicationContext, "Store deleted", Toast.LENGTH_SHORT).show()
                            }
                        } catch (e: Exception) {
                            withContext(Dispatchers.Main) {
                                Toast.makeText(applicationContext, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                }

                row.addView(textViewId)
                row.addView(editStoreName)
                row.addView(editStoreCategory)
                row.addView(buttonUpdate)
                row.addView(buttonDelete)
                storesTable.addView(row)
            }
        }

        // Виведення усіх продуктів
        dao.getAllProducts().asLiveData().observe(this) { products ->
            val productsTable = binding.productsTable
            productsTable.removeAllViews()

            // Заголовки
            val headersRow = TableRow(this)
            val textViewId = TextView(this)
            val textViewProductName = TextView(this)
            val textViewStoreCategory = TextView(this)
            val textViewProductPrice = TextView(this)

            textViewId.text = "id"
            textViewProductName.text = "product_name"
            textViewStoreCategory.text = "store_category"
            textViewProductPrice.text = "product_price"

            headersRow.addView(textViewId)
            headersRow.addView(textViewProductName)
            headersRow.addView(textViewStoreCategory)
            headersRow.addView(textViewProductPrice)
            productsTable.addView(headersRow)

            products.forEach { product ->
                val row = TableRow(this)

                val textViewProductId = TextView(this)
                val editTextProductNameValue = EditText(this)
                val editTextStoreCategoryValue = EditText(this)
                val editTextProductPriceValue = EditText(this)
                val updateButton = Button(this)
                updateButton.text = "Update"
                updateButton.isEnabled = false
                val deleteButton = Button(this)
                deleteButton.text = "Delete"

                textViewProductId.text = product.productId.toString()
                editTextProductNameValue.setText(product.productName)
                editTextStoreCategoryValue.setText(product.storeCategory)
                editTextProductPriceValue.setText(product.productPrice.toString())

                row.addView(textViewProductId)
                row.addView(editTextProductNameValue)
                row.addView(editTextStoreCategoryValue)
                row.addView(editTextProductPriceValue)
                row.addView(updateButton)
                row.addView(deleteButton)

                // Розблокування кнопки Update
                editTextProductNameValue.addTextChangedListener {
                    updateButton.isEnabled = true
                }
                editTextStoreCategoryValue.addTextChangedListener {
                    updateButton.isEnabled = true
                }
                editTextProductPriceValue.addTextChangedListener {
                    updateButton.isEnabled = true
                }

                // Обробка оновлення
                updateButton.setOnClickListener {
                    CoroutineScope(Dispatchers.IO).launch {
                        try {
                            product.productName = editTextProductNameValue.text.toString()
                            product.storeCategory = editTextStoreCategoryValue.text.toString()
                            product.productPrice = editTextProductPriceValue.text.toString().toDoubleOrNull()
                            dao.updateProduct(product)
                            withContext(Dispatchers.Main) {
                                Toast.makeText(applicationContext, "Product updated", Toast.LENGTH_SHORT).show()
                            }
                        } catch (e: Exception) {
                            withContext(Dispatchers.Main) {
                                Toast.makeText(applicationContext, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                }

                // Обробка видалення
                deleteButton.setOnClickListener {
                    CoroutineScope(Dispatchers.IO).launch {
                        try {
                            dao.deleteProduct(product)

                            withContext(Dispatchers.Main) {
                                Toast.makeText(applicationContext, "Product deleted", Toast.LENGTH_SHORT).show()
                            }
                        } catch (e: Exception) {
                            withContext(Dispatchers.Main) {
                                Toast.makeText(applicationContext, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                }

                productsTable.addView(row)
            }
        }
    }

    fun buttonAddStoreClick(view: View) {
        if (binding.editTextStoreName.text.toString() == "" || binding.editTextStoreCategory.text.toString() == "")
            return

        CoroutineScope(Dispatchers.IO).launch {
            try {
                val store = Store(null, binding.editTextStoreName.text.toString(), binding.editTextStoreCategory.text.toString())
                dao.insertStore(store)
                withContext(Dispatchers.Main) {
                    binding.editTextStoreName.text.clear()
                    binding.editTextStoreCategory.text.clear()
                }
            } catch (ex: Exception) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(applicationContext, "Error: ${ex.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    fun addProductClick(view: View)
    {
        val productName = binding.editTextNewProductName.text.toString()
        val productPrice = binding.editTextNewProductPrice.text.toString().toDoubleOrNull()
        val storeCategory = (binding.spinnerStores.selectedItem as Store).storeCategory

        if (productName == "" || productPrice == 0.0)
            return

        CoroutineScope(Dispatchers.IO).launch {
            try {
                val product = Product(null, productName, storeCategory, productPrice)
                dao.insertProduct(product)
                withContext(Dispatchers.Main) {
                    binding.editTextNewProductName.text.clear()
                    binding.editTextNewProductPrice.text.clear()
                }
            } catch (ex: Exception) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(applicationContext, "Error: ${ex.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    fun openFullTableClick(view: View)
    {
        val intent = Intent(this, JointTable::class.java)
        startActivity(intent)
    }
}