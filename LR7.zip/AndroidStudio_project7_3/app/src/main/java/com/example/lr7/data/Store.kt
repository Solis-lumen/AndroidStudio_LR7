/*
package com.example.lr7.data
import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "stores", indices = [Index(value = ["store_category"], unique = true)])
data class Store (
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "store_id")
    var id: Int? = null,
    @ColumnInfo(name = "store_name")
    var name : String,
    @ColumnInfo(name = "store_category")
    var categоry : String
)
*/




package com.example.lr7.data

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "stores",
    indices = [Index(value = ["store_category"], unique = true)]
)

data class Store(
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "store_id")
    var storeId: Int? = null,

    @ColumnInfo(name = "store_name")
    var storeName: String,

    @ColumnInfo(name = "store_category")
    var storeCategory: String
)
