/*
package com.example.lr7.data
import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.PrimaryKey

@Entity(tableName = "products",
    foreignKeys = [
        ForeignKey(
            entity = Store::class,
            parentColumns = arrayOf("store_category"),
            childColumns = arrayOf("store_category"),
            onUpdate = ForeignKey.CASCADE,
            onDelete = ForeignKey.CASCADE
        )
    ]
)

data class Product (
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "product_id")
    val id: Int? = null,
    @ColumnInfo(name = "product_name")
    var name: String,
    @ColumnInfo(name = "store_category")
    var store_category : String,
    @ColumnInfo(name = "product_price")
    var price: Double?
)
*/





package com.example.lr7.data

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.PrimaryKey

@Entity(
    tableName = "products",
    foreignKeys = [
        ForeignKey(
            entity = Store::class,
            parentColumns = arrayOf("store_category"),
            childColumns = arrayOf("store_category"),
            onUpdate = ForeignKey.CASCADE,
            onDelete = ForeignKey.CASCADE
        )
    ]
)

data class Product(
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "product_id")
    val productId: Int? = null,
    @ColumnInfo(name = "product_name")
    var productName: String,
    @ColumnInfo(name = "store_category")
    var storeCategory: String,
    @ColumnInfo(name = "product_price")
    var productPrice: Double?
)
