/*
package com.example.lr7.data

data class ProductWithStore(
    val product_id: Int,
    val product_name: String,
    val product_price: Double,
    val store_id: Int,
    val store_name: String,
    val store_category: String
)
*/





package com.example.lr7.data

import androidx.room.Embedded
import androidx.room.Relation

data class ProductWithStore(
    @Embedded val store: Store,
    @Relation(
        parentColumn = "store_category",
        entityColumn = "store_category"
    )
    val products: List<Product>
)
